#!/usr/bin/env python3
"""Verify correlation in an authenticated encrypted index; never fetch LINE.
Bundled with the reader skill; client installation must be verified separately.
The receipt is authenticated by the archive key, not a device-only signing key.
"""
import argparse
import json
import re
import sys
from pathlib import Path
from datetime import datetime, timezone
# Load the packaged sibling even when the caller uses Python isolated mode (-I).
# Resolve symlinks so the development tools entry point uses the same owner.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from read_encrypted_archive import Reader, ArchiveError


def verify(index, request_id, not_before, observed_at=None):
    def time(value):
        if not isinstance(value, str):
            raise ValueError()
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if result.utcoffset() is None:
            raise ValueError()
        return result.astimezone(timezone.utc)
    if not isinstance(request_id, str) or not re.fullmatch(r'[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}', request_id):
        raise ArchiveError('invalid_request_id')
    try:
        minimum = time(not_before)
        observed = time(observed_at or datetime.now(timezone.utc).isoformat())
        if minimum > observed:
            raise ValueError()
    except (ValueError, OverflowError):
        raise ArchiveError('invalid_observation_time')
    fallback = {'completed': False, 'mode': 'saved_snapshot', 'reason': 'matching_receipt_unavailable'}
    if not isinstance(index, dict) or type(index.get('schema')) is not int or index['schema'] != 1:
        return {**fallback, 'reason': 'invalid_index'}
    receipt = index.get('refresh_receipt')
    if not isinstance(receipt, dict) or receipt.get('request_id') != request_id:
        return fallback
    try:
        if type(receipt.get('schema')) is not int or receipt['schema'] != 1:
            raise ValueError()
        issued, start, end = [time(receipt.get(k)) for k in ('issued_at', 'started_at', 'completed_at')]
        if not minimum <= issued <= start <= end <= observed:
            raise ValueError()
        captures, enabled, chats = receipt['captures'], index['enabled'], index['chats']
        if (not isinstance(captures, list) or not isinstance(enabled, list) or not isinstance(chats, list)
                or not enabled or any(not isinstance(x, str) or not x for x in enabled)
                or any(not isinstance(c, dict) or not isinstance(c.get('chat_id'), str) or not c['chat_id'] for c in captures)
                or any(not isinstance(c, dict) or not isinstance(c.get('chatID'), str) or not c['chatID'] for c in chats)
                or len(set(enabled)) != len(enabled)):
            raise ValueError()
        if len(captures) != len(enabled) or {c['chat_id'] for c in captures} != set(enabled):
            raise ValueError()
        for c in captures:
            matches = [chat for chat in chats if chat['chatID'] == c['chat_id']]
            if len(matches) != 1:
                raise ValueError()
            current = matches[0]
            fetched, uploaded = time(c['fetched_at']), time(c['uploaded_at'])
            if not start <= fetched <= uploaded <= end:
                raise ValueError()
            if c['fetched_at'] != current.get('last_fetch_saved_at') or c['uploaded_at'] != current.get('last_sync_at'):
                raise ValueError()
        return {'completed': True, 'mode': 'captured_for_request', 'request_id': request_id,
                'started_at': receipt['started_at'], 'completed_at': receipt['completed_at'],
                'checked_chats': len(captures), 'device_signature_verified': False}
    except (ValueError, TypeError, KeyError, OverflowError):
        return {**fallback, 'reason': 'receipt_inconsistent_with_snapshot'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--key-file')
    parser.add_argument('--request-id', required=True)
    parser.add_argument('--not-before', required=True, help='Observed AI update instruction time, ISO8601 with timezone')
    args = parser.parse_args()
    reader = Reader(args.key_file, args.root)
    if reader.repository != 'altis0725/line-conversation-archive':
        raise ArchiveError('repository_not_approved')
    index, _ = reader.catalog()  # Authenticates ciphertext before examining receipt.
    print(json.dumps(verify(index, args.request_id, args.not_before)))

if __name__ == '__main__':
    try:
        main()
    except Exception:
        # No partial plaintext or exception input on authentication/scope failures.
        print(json.dumps({'completed': False, 'error': 'receipt_verification_failed'}))
        raise SystemExit(1)
